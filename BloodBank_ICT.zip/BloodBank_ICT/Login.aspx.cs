﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Btnlogin_Click(object sender, EventArgs e)
    {
       
        if(TextBox1.Text == "admin@gmail.com" || TextBox2.Text == "1234")
        {
            Label1.Text = "Login Successfuly";
            Response.Redirect("Admin.aspx");
        }
        else
        {
            Label2.Text = "Invalid credentials";
        }

    }


    protected void btnClear_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
    }
}